import { DataTypes } from 'sequelize';
import sequelize from '../db.js';

const HomeContent = sequelize.define(
  'HomeContent',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: false,
    },
    data: {
      type: DataTypes.JSON,
      allowNull: false,
      defaultValue: {},
    },
  },
  {
    tableName: 'home_content',
    underscored: true,
    timestamps: true,
  }
);

export default HomeContent;
